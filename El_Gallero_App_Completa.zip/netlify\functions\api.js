const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const DB_PATH = path.join(__dirname, '..', '..', 'data', 'db.json');

function getLocalDateString(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

app.use(cors());
app.use(express.json());

const DEFAULT_DB = {
  settings: {
    storeName: "EL GALLERO",
    subtitle: "100% cotto a legna",
    phone: "3775975734",
    address: "Girarrosto El Gallero - 100% Cotto a Legna",
    adminPin: "230888",
    currency: "€",
    timeSlots: [
      "11:45", "12:00", "12:15", "12:30", "12:45", "13:00", "13:15", "13:30", "13:45", "14:00",
      "18:30", "18:45", "19:00", "19:15", "19:30", "19:45", "20:00", "20:15", "20:30", "20:45", "21:00", "21:30"
    ]
  },
  categories: [
    { id: "pollo", name: "Pollo", icon: "🍗", description: "Cotto a legna allo spiedo, morbido e succulento" },
    { id: "fritto", name: "Fritto", icon: "🍟", description: "Fritture croccanti e dorate al momento" },
    { id: "sfizi", name: "Sfizi", icon: "🍢", description: "Spiedini, salsicce e sfiziosità alla brace" },
    { id: "bibite", name: "Bibite", icon: "🥤", description: "Bevande fresche e birre selezionate" }
  ],
  products: [
    { id: "p1", category: "pollo", name: "Pollo intero", price: 8.00, stock: 15, unlimited: false, description: "Pollo intero girarrosto cotto a legna", available: true },
    { id: "p2", category: "pollo", name: "Mezzo pollo", price: 5.00, stock: 10, unlimited: false, description: "Mezzo pollo girarrosto dorato", available: true },
    { id: "p3", category: "pollo", name: "Pollo e patate", price: 10.00, stock: 12, unlimited: false, description: "Pollo intero girarrosto con contorno di patate al forno", available: true },
    { id: "p4", category: "pollo", name: "Mezzo pollo con patate", price: 8.00, stock: 8, unlimited: false, description: "Mezzo pollo girarrosto con contorno di patate al forno", available: true },
    { id: "p5", category: "pollo", name: "Patata grande", price: 5.00, stock: 15, unlimited: false, description: "Porzione abbondante di patate al forno speziate", available: true },
    { id: "p6", category: "pollo", name: "Patata piccola", price: 3.00, stock: 20, unlimited: false, description: "Porzione classica di patate al forno speziate", available: true },
    { id: "f1", category: "fritto", name: "Croccantella", price: 3.00, stock: 10, unlimited: false, description: "Croccante e sfiziosa", available: true },
    { id: "f2", category: "fritto", name: "Pollo fritto (3 pezzi)", price: 2.00, stock: 12, unlimited: false, description: "3 bocconcini di pollo croccante panato dorato", available: true },
    { id: "s1", category: "sfizi", name: "Salsiccia", price: 2.00, stock: 20, unlimited: false, description: "Salsiccia saporita alla brace", available: true },
    { id: "s2", category: "sfizi", name: "Spiedino", price: 2.50, stock: 15, unlimited: false, description: "Spiedino misto cotto a legna", available: true },
    { id: "s3", category: "sfizi", name: "Ali di pollo (al pezzo)", price: 1.00, stock: 25, unlimited: false, description: "Aletta di pollo speziata e arrostita a legna (prezzo al pezzo)", available: true },
    { id: "s4", category: "sfizi", name: "Fuselli (al pezzo)", price: 2.00, stock: 18, unlimited: false, description: "Fusello di pollo arrosto dorato (prezzo al pezzo)", available: true },
    { id: "b1", category: "bibite", name: "Pepsi Cola", price: 2.50, stock: 30, unlimited: true, description: "Lattina / Bottiglietta fresca 33cl", available: true },
    { id: "b2", category: "bibite", name: "Birra piccola", price: 1.50, stock: 24, unlimited: true, description: "Birra fresca 33cl", available: true },
    { id: "b3", category: "bibite", name: "Birra grande", price: 2.50, stock: 24, unlimited: true, description: "Birra fresca 66cl", available: true }
  ],
  bookings: []
};

// In-memory / file cache for Netlify environment
let memoryDB = null;

function readDB() {
  if (memoryDB) return memoryDB;
  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf8');
      memoryDB = JSON.parse(raw);
      return memoryDB;
    }
  } catch (err) {
    console.error('Error reading db in function:', err);
  }
  memoryDB = JSON.parse(JSON.stringify(DEFAULT_DB));
  return memoryDB;
}

function writeDB(data) {
  memoryDB = data;
  try {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    // In read-only serverless environment, memoryDB handles session
  }
  return true;
}

function requireAdmin(req, res, next) {
  const pin = req.headers['x-admin-pin'] || req.query.pin;
  const db = readDB();
  const validPin = (db.settings && db.settings.adminPin) ? db.settings.adminPin : '230888';
  
  if (pin && String(pin) === String(validPin)) {
    return next();
  }
  return res.status(401).json({ success: false, message: 'PIN amministratore non valido o mancante.' });
}

// Router for /.netlify/functions/api and /api
const router = express.Router();

router.get('/info', (req, res) => {
  const db = readDB();
  const { adminPin, ...publicSettings } = db.settings || {};
  res.json({ success: true, settings: publicSettings });
});

router.get('/menu', (req, res) => {
  const db = readDB();
  res.json({ success: true, categories: db.categories || [], products: db.products || [] });
});

router.post('/bookings', (req, res) => {
  const { customerName, customerPhone, pickupDate, pickupTime, allergens, items, notes, orderType, deliveryAddress } = req.body;
  if (!customerName || !customerPhone || !pickupTime || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ success: false, message: 'Dati incompleti.' });
  }

  if (orderType === 'domicilio' && (!deliveryAddress || !deliveryAddress.trim())) {
    return res.status(400).json({ success: false, message: 'Inserisci l\'indirizzo per la consegna a domicilio.' });
  }

  const db = readDB();
  let itemsSubtotal = 0;
  const validatedItems = [];

  for (const item of items) {
    const qty = parseInt(item.quantity, 10);
    if (qty > 0) {
      const prodInDb = (db.products || []).find(p => p.id === item.id);
      const unitPrice = prodInDb ? prodInDb.price : Number(item.price || 0);
      const subtotal = qty * unitPrice;
      itemsSubtotal += subtotal;

      validatedItems.push({
        id: item.id,
        name: item.name,
        category: item.category || 'altro',
        price: unitPrice,
        quantity: qty,
        subtotal: Number(subtotal.toFixed(2))
      });

      if (prodInDb && !prodInDb.unlimited) {
        prodInDb.stock = Math.max(0, (prodInDb.stock || 0) - qty);
        if (prodInDb.stock === 0) prodInDb.available = false;
      }
    }
  }

  const isDelivery = (orderType === 'domicilio');
  const deliveryFee = isDelivery ? 2.00 : 0.00;
  const totalAmount = Number((itemsSubtotal + deliveryFee).toFixed(2));

  const randomCode = 'EG-' + Math.floor(1000 + Math.random() * 9000);
  const now = new Date();

  const newBooking = {
    id: 'bkg_' + Date.now(),
    code: randomCode,
    customerName: customerName.trim(),
    customerPhone: customerPhone.trim(),
    pickupDate: pickupDate || getLocalDateString(now),
    pickupTime: pickupTime.trim(),
    orderType: isDelivery ? 'domicilio' : 'ritiro',
    orderTypeText: isDelivery ? 'Consegna a Domicilio' : 'Ritiro in Sede (Asporto)',
    deliveryAddress: isDelivery ? deliveryAddress.trim() : '',
    deliveryFee: deliveryFee,
    itemsSubtotal: Number(itemsSubtotal.toFixed(2)),
    allergens: (allergens || '').trim(),
    notes: (notes || '').trim(),
    items: validatedItems,
    totalAmount: totalAmount,
    status: 'in_attesa',
    statusText: 'In attesa di conferma',
    createdAt: now.toISOString(),
    updatedAt: now.toISOString()
  };

  db.bookings = db.bookings || [];
  db.bookings.unshift(newBooking);
  writeDB(db);

  res.status(201).json({ success: true, booking: newBooking });
});

router.get('/bookings/:idOrCode', (req, res) => {
  const db = readDB();
  const booking = (db.bookings || []).find(b => b.id === req.params.idOrCode || b.code === req.params.idOrCode);
  if (!booking) return res.status(404).json({ success: false, message: 'Non trovata.' });
  res.json({ success: true, booking });
});

router.post('/admin/login', (req, res) => {
  const { pin } = req.body;
  const db = readDB();
  const validPin = (db.settings && db.settings.adminPin) ? db.settings.adminPin : '280690';
  if (String(pin) === String(validPin)) return res.json({ success: true });
  return res.status(401).json({ success: false, message: 'PIN errato.' });
});

router.get('/admin/bookings', requireAdmin, (req, res) => {
  const db = readDB();
  res.json({ success: true, bookings: db.bookings || [] });
});

router.patch('/admin/bookings/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const index = (db.bookings || []).findIndex(b => b.id === req.params.id || b.code === req.params.id);
  if (index === -1) return res.status(404).json({ success: false });

  Object.assign(db.bookings[index], req.body);
  const booking = db.bookings[index];
  
  if (req.body.fidelityDiscount !== undefined) {
    booking.fidelityDiscount = Number(req.body.fidelityDiscount || 0);
  }
  
  const itemsSub = booking.itemsSubtotal !== undefined ? booking.itemsSubtotal : (booking.items || []).reduce((s, it) => s + (it.quantity * it.price), 0);
  const delivFee = booking.deliveryFee !== undefined ? booking.deliveryFee : (booking.orderType === 'domicilio' ? 2.00 : 0.00);
  const fidDisc = Number(booking.fidelityDiscount || 0);
  booking.totalAmount = Math.max(0, Number((itemsSub + delivFee - fidDisc).toFixed(2)));

  writeDB(db);
  res.json({ success: true, booking: db.bookings[index] });
});

router.delete('/admin/bookings/:id', requireAdmin, (req, res) => {
  const db = readDB();
  db.bookings = (db.bookings || []).filter(b => b.id !== req.params.id && b.code !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

router.get('/admin/customers', requireAdmin, (req, res) => {
  const db = readDB();
  const bookings = db.bookings || [];
  const customerMap = {};

  for (const b of bookings) {
    const rawPhone = (b.customerPhone || '').trim();
    const cleanPhone = rawPhone.replace(/\D/g, '');
    const key = cleanPhone.length >= 6 ? cleanPhone : (b.customerName || 'Cliente').toLowerCase().trim();

    if (!customerMap[key]) {
      customerMap[key] = {
        id: 'cust_' + (cleanPhone || Math.random().toString(36).substr(2, 6)),
        name: b.customerName ? b.customerName.trim() : 'Cliente',
        phone: b.customerPhone ? b.customerPhone.trim() : 'N/D',
        cleanPhone: cleanPhone,
        totalOrders: 0,
        totalSpent: 0,
        completedOrders: 0,
        pendingOrders: 0,
        lastOrderDate: b.pickupDate || b.createdAt.split('T')[0],
        lastOrderTime: b.pickupTime || '',
        lastOrderCode: b.code || '',
        lastOrderType: b.orderType || 'ritiro',
        lastDeliveryAddress: b.deliveryAddress || '',
        firstSeen: b.createdAt || new Date().toISOString(),
        notes: b.notes || '',
        isVip: false
      };
    }

    const c = customerMap[key];
    if (b.status !== 'annullato') {
      c.totalOrders += 1;
      c.totalSpent += Number(b.totalAmount || 0);
      if (b.status === 'completato') c.completedOrders += 1;
      if (b.status === 'in_attesa') c.pendingOrders += 1;
    }

    if (b.customerName && b.customerName.trim()) c.name = b.customerName.trim();
    if (b.deliveryAddress && b.deliveryAddress.trim()) c.lastDeliveryAddress = b.deliveryAddress.trim();

    if (b.pickupDate && b.pickupDate >= c.lastOrderDate) {
      c.lastOrderDate = b.pickupDate;
      c.lastOrderTime = b.pickupTime || c.lastOrderTime;
      c.lastOrderCode = b.code || c.lastOrderCode;
      c.lastOrderType = b.orderType || c.lastOrderType;
    }
  }

  const customersList = Object.values(customerMap).map(c => {
    c.totalSpent = Number(c.totalSpent.toFixed(2));
    c.isVip = c.totalOrders >= 2 || c.totalSpent >= 25.00;
    return c;
  });

  customersList.sort((a, b) => (b.lastOrderDate + b.lastOrderTime).localeCompare(a.lastOrderDate + a.lastOrderTime));

  res.json({
    success: true,
    customers: customersList,
    totalCount: customersList.length,
    vipCount: customersList.filter(c => c.isVip).length
  });
});

router.post('/admin/customers/clear', requireAdmin, (req, res) => {
  const db = readDB();
  db.bookings = [];
  db.customers = [];
  writeDB(db);
  res.json({ success: true, message: 'Rubrica svuotata.' });
});

router.patch('/admin/products/:id/stock', requireAdmin, (req, res) => {
  const { delta, exactStock, unlimited } = req.body;
  const db = readDB();
  const prod = (db.products || []).find(p => p.id === req.params.id);
  if (!prod) return res.status(404).json({ success: false });

  if (unlimited !== undefined) prod.unlimited = Boolean(unlimited);
  if (exactStock !== undefined) prod.stock = Math.max(0, parseInt(exactStock, 10) || 0);
  else if (delta !== undefined) prod.stock = Math.max(0, (prod.stock || 0) + parseInt(delta, 10));

  prod.available = prod.unlimited ? true : (prod.stock > 0);
  writeDB(db);
  res.json({ success: true, product: prod });
});

router.post('/admin/products', requireAdmin, (req, res) => {
  const db = readDB();
  const newProd = { id: 'prod_' + Date.now(), ...req.body };
  db.products = db.products || [];
  db.products.push(newProd);
  writeDB(db);
  res.status(201).json({ success: true, product: newProd });
});

router.put('/admin/products/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const idx = (db.products || []).findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false });
  Object.assign(db.products[idx], req.body);
  writeDB(db);
  res.json({ success: true, product: db.products[idx] });
});

router.delete('/admin/products/:id', requireAdmin, (req, res) => {
  const db = readDB();
  db.products = (db.products || []).filter(p => p.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

router.post('/admin/settings', requireAdmin, (req, res) => {
  const db = readDB();
  db.settings = { ...(db.settings || {}), ...req.body };
  writeDB(db);
  res.json({ success: true, settings: db.settings });
});

router.get('/admin/stats', requireAdmin, (req, res) => {
  const db = readDB();
  const bookings = db.bookings || [];
  const today = getLocalDateString();
  const todayBookings = bookings.filter(b => b.pickupDate === today);

  res.json({
    success: true,
    stats: {
      totalBookings: bookings.length,
      todayBookingsCount: todayBookings.length,
      pendingCount: bookings.filter(b => b.status === 'in_attesa').length,
      confirmedCount: bookings.filter(b => b.status === 'confermato').length,
      completedCount: bookings.filter(b => b.status === 'completato').length,
      todayRevenue: todayBookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0)
    }
  });
});

app.use('/.netlify/functions/api', router);
app.use('/api', router);

module.exports.handler = serverless(app);