@echo off
title EL GALLERO - Server Prenotazioni
echo =======================================================
echo     ?? AVVIO APPLICAZIONE EL GALLERO - COTTO A LEGNA ??
echo =======================================================
echo.

set "NODE_EXE=C:\Users\enric\.gemini\antigravity\tools\node\node.exe"

if exist "%NODE_EXE%" (
    "%NODE_EXE%" server.js
) else (
    node server.js
)

pause